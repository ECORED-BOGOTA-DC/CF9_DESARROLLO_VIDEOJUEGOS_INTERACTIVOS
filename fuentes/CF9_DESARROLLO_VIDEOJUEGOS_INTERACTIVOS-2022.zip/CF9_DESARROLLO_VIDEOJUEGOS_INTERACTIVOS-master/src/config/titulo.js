module.exports = 'Programación de eventos de personajes y entornos'
